﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class tbl_KampanyaController : ApiController
    {
        private reklamdbEntities2 db = new reklamdbEntities2();

        // GET: api/tbl_Kampanya
        public IQueryable<tbl_Kampanya> Gettbl_Kampanya()
        {
            return db.tbl_Kampanya;
        }

        // GET: api/tbl_Kampanya/5
        [ResponseType(typeof(tbl_Kampanya))]
        public IHttpActionResult Gettbl_Kampanya(int id)
        {
            tbl_Kampanya tbl_Kampanya = db.tbl_Kampanya.Find(id);
            if (tbl_Kampanya == null)
            {
                return NotFound();
            }

            return Ok(tbl_Kampanya);
        }

        // PUT: api/tbl_Kampanya/5
        [ResponseType(typeof(void))]
        public IHttpActionResult Puttbl_Kampanya(int id, tbl_Kampanya tbl_Kampanya)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tbl_Kampanya.FirmaID)
            {
                return BadRequest();
            }

            db.Entry(tbl_Kampanya).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tbl_KampanyaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/tbl_Kampanya
        [ResponseType(typeof(tbl_Kampanya))]
        public IHttpActionResult Posttbl_Kampanya(tbl_Kampanya tbl_Kampanya)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tbl_Kampanya.Add(tbl_Kampanya);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = tbl_Kampanya.FirmaID }, tbl_Kampanya);
        }

        // DELETE: api/tbl_Kampanya/5
        [ResponseType(typeof(tbl_Kampanya))]
        public IHttpActionResult Deletetbl_Kampanya(int id)
        {
            tbl_Kampanya tbl_Kampanya = db.tbl_Kampanya.Find(id);
            if (tbl_Kampanya == null)
            {
                return NotFound();
            }

            db.tbl_Kampanya.Remove(tbl_Kampanya);
            db.SaveChanges();

            return Ok(tbl_Kampanya);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tbl_KampanyaExists(int id)
        {
            return db.tbl_Kampanya.Count(e => e.FirmaID == id) > 0;
        }
    }
}