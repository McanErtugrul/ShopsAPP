﻿using Mvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace Mvc.Controllers
{
    public class KampanyaController : Controller
    {
        // GET: Kampanya
        public ActionResult Index()
        {

            IEnumerable<mvcKampanyaModel> kampanyalist;
            HttpResponseMessage response = GlolabVariables.WebApiClient.GetAsync("tbl_Kampanya").Result;
            kampanyalist = response.Content.ReadAsAsync<IEnumerable<mvcKampanyaModel>>().Result;

            return View(kampanyalist);
        }

        public ActionResult AddOrEdit(int id=0)
        {
            if (id == 0)
            {
                return View(new mvcKampanyaModel());
            }
            else
            {
                HttpResponseMessage response = GlolabVariables.WebApiClient.GetAsync("tbl_Kampanya/"+id.ToString()).Result;
                return View(response.Content.ReadAsAsync<mvcKampanyaModel>().Result);

            }

            

        }
        [HttpPost]
        public ActionResult AddOrEdit(mvcKampanyaModel kampanya)
        {
            if (kampanya.FirmaID == 0)
            {
                HttpResponseMessage response = GlolabVariables.WebApiClient.PostAsJsonAsync("tbl_Kampanya", kampanya).Result;
                TempData["SuccesMesseage"] = "Kayıt Başarılı";
            }
            else
            {
                HttpResponseMessage response = GlolabVariables.WebApiClient.PutAsJsonAsync("tbl_Kampanya/"+kampanya.FirmaID, kampanya).Result;
                TempData["SuccesMesseage"] = "Güncelleme Başarılı";
            }

            return RedirectToAction("Index");

        }


        public ActionResult Sil(int id)
        {
             HttpResponseMessage response = GlolabVariables.WebApiClient.DeleteAsync("tbl_Kampanya/" + id.ToString()).Result;

            TempData["SuccesMesseage"] = "Silme Başarılı";
            return RedirectToAction("Index");
        }
    }
}