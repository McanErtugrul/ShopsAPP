﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc.Models
{
    public class mvcKampanyaModel
    {
        public int FirmaID { get; set; }
        public string FirmaAdi { get; set; }
        public Nullable<double> LAT { get; set; }
        public Nullable<double> LONG { get; set; }
        public string KampanyaTur { get; set; }
        public string KampanyaIcerik { get; set; }
        public Nullable<int> KampanyaSuresi { get; set; }
    }
}